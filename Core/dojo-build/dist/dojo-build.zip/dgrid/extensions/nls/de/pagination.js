//>>built
define("dgrid/extensions/nls/de/pagination",{status:"${start} - ${end} von ${total} Ergebnissen",gotoFirst:"Gehe zu erster Seite",gotoNext:"Gehe zu n\u00e4chster Seite",gotoPrev:"Gehe zu vorheriger Seite",gotoLast:"Gehe zu letzter Seite",gotoPage:"Gehe zu Seite",jumpPage:"Springe zu Seite"});
//@ sourceMappingURL=pagination.js.map