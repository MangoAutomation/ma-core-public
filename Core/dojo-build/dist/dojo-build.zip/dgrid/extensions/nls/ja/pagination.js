//>>built
define("dgrid/extensions/nls/ja/pagination",{status:"\u691c\u7d22\u7d50\u679c${total}\u4ef6\u4e2d${start}\u4ef6\u304b\u3089${end}\u4ef6\u307e\u3067\u3092\u8868\u793a\u3002"});
//@ sourceMappingURL=pagination.js.map