//>>built
define("dgrid/extensions/nls/pagination",{root:{status:"${start} - ${end} of ${total} results",gotoFirst:"Go to first page",gotoNext:"Go to next page",gotoPrev:"Go to previous page",gotoLast:"Go to last page",gotoPage:"Go to page",jumpPage:"Jump to page"},de:!0,es:!0,fr:!0,pt:!0,ja:!0,sk:!0,th:!0,"zh-cn":!0,"zh-hk":!0});
//@ sourceMappingURL=pagination.js.map