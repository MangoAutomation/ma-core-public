//>>built
define("dgrid/extensions/nls/sk/pagination",{status:"${start} - ${end} z ${total} v\u00fdsledkov",gotoFirst:"Prv\u00e1 str\u00e1nka",gotoNext:"Nasledovn\u00e1 str\u00e1nka",gotoPrev:"Predch\u00e1dzaj\u00faca str\u00e1nka",gotoLast:"Posledn\u00e1 str\u00e1nka",gotoPage:"Na str\u00e1nku",jumpPage:"Na str\u00e1nku"});
//@ sourceMappingURL=pagination.js.map