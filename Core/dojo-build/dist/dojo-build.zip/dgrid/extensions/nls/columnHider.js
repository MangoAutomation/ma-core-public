//>>built
define("dgrid/extensions/nls/columnHider",{root:{popupLabel:"Show or hide columns"},es:!0});
//@ sourceMappingURL=columnHider.js.map