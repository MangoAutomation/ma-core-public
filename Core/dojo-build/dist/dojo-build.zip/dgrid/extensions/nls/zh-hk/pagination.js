//>>built
define("dgrid/extensions/nls/zh-hk/pagination",{status:"${start} - ${end} \u5171 ${total} \u689d\u7d50\u679c",gotoFirst:"\u9996\u9801",gotoNext:"\u4e0a\u4e00\u9801",gotoPrev:"\u4e0b\u4e00\u9801",gotoLast:"\u672b\u9801",gotoPage:"\u5230\u9019\u9801",jumpPage:"\u8df3\u5230\u9801"});
//@ sourceMappingURL=pagination.js.map