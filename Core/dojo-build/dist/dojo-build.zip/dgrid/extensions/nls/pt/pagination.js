//>>built
define("dgrid/extensions/nls/pt/pagination",{status:"${start} - ${end} de ${total} resultados",gotoFirst:"Primeira p\u00e1gina",gotoNext:"Pr\u00f3xima p\u00e1gina",gotoPrev:"P\u00e1gina anterior",gotoLast:"\u00daltima p\u00e1gina",gotoPage:"Ir para p\u00e1gina",jumpPage:"Pular para p\u00e1gina"});
//@ sourceMappingURL=pagination.js.map