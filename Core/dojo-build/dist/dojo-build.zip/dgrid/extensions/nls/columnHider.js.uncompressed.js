define("dgrid/extensions/nls/columnHider", {
	root: {
		popupLabel: 'Show or hide columns'
	},
	es: true
});
