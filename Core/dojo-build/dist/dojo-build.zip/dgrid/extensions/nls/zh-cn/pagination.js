//>>built
define("dgrid/extensions/nls/zh-cn/pagination",{status:"${start} - ${end} \u5171 ${total} \u6761\u7ed3\u679c",gotoFirst:"\u9996\u9875",gotoNext:"\u540e\u4e00\u9875",gotoPrev:"\u524d\u4e00\u9875",gotoLast:"\u672b\u9875",gotoPage:"\u5230\u8fd9\u9875",jumpPage:"\u8df3\u5230\u9875"});
//@ sourceMappingURL=pagination.js.map