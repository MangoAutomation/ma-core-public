//>>built
define("dijit/_base/typematic",["../typematic"],function(){});
//@ sourceMappingURL=typematic.js.map