define(
"dijit/_editor/nls/he/LinkDialog", ({
	createLinkTitle: "תכונות קישור",
	insertImageTitle: "תכונות תמונה",
	url: "URL:‏",
	text: "תיאור:",
	target: "יעד:",
	set: "הגדרה",
	currentWindow: "חלון נוכחי",
	parentWindow: "חלון אב",
	topWindow: "חלון עליון",
	newWindow: "חלון חדש"
})
);
